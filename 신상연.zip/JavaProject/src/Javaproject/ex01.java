package Javaproject;

import java.util.Scanner;

public class ex01 {
	static long fibo(long n) {
		if (n == 1) {
			return 1;
		} else {
			return n * fibo(n - 1);
		}
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("�������� �Է��ϼ���");
		long num = sc.nextLong();
		fibo(num);
		System.out.println(fibo(num));

	}

}
