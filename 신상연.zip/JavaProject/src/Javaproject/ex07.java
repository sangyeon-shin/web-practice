package Javaproject;

import java.util.Scanner;

public class ex07 {
	
	public static void main(String[] args) {
	      Scanner sc = new Scanner(System.in);
	      
	      System.out.print("2������ ��ȯ�� ���� �Է�>");
	      int x=sc.nextInt();
	      
	      System.out.println("10����: "+ x);
	      System.out.print("2����: ");
	      for(int i=31; i>=0; i--) {
	         int temp;
	         temp= x>>i;
	         System.out.print(temp&1);               
	      }
	      
	      System.out.println();
	      System.out.println("2����: "+Integer.toBinaryString(x));
	      
	      sc.close();}
}
