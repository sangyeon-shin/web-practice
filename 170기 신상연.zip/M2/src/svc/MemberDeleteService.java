package svc;

import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.sql.ResultSet;

import dao.MemberDAO;
import vo.Member;
import static db.JdbcUtil.*;

public class MemberDeleteService {
	
	public boolean deleteMember(Member deleteMember) {
		boolean isDeleteSuccess = false;
		Connection con = getConnection();
		MemberDAO memberDAO = new MemberDAO(con);
		
		int deleteCount = memberDAO.deleteMember(deleteMember);
		
		if(deleteCount > 0) {
			commit(con);
			isDeleteSuccess = true;
		}else {
			rollback(con);
		}
		return isDeleteSuccess;
	}

}
