package action;

import java.util.Scanner;

import svc.MemberAddService;
import util.ConsoleUtil;
import vo.Member;

public class MemberUpdateAction implements Action {
	
	@Override
	public void execute(Scanner sc) throws Exception {
		
		ConsoleUtil cu = new ConsoleUtil();
		Member updateMember = cu.getUpdateMember(sc);
		
		MemberUpdateService memberUpdateService = new MemberUpdateService();	
		
	}
}
