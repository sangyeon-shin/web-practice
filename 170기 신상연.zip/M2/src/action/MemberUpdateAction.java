package action;

import java.util.Scanner;

import svc.MemberUpdateService;
import util.ConsoleUtil;
import vo.Member;

public class MemberUpdateAction implements Action {
	
	@Override
	public void execute(Scanner sc) throws Exception {
		
		ConsoleUtil cu = new ConsoleUtil();
		Member updateMember = cu.getUpdateMember(sc);
		
		MemberUpdateService memberUpdateService = new MemberUpdateService();	
		
		boolean isUpdateSuccess = memberUpdateService.updateMember(updateMember);
		if(isUpdateSuccess) {
			System.out.println(updateMember.getName()+"ȸ�� ���� ���� ����");
		}else {
			System.out.println(updateMember.getName()+"ȸ�� ���� ���� ����");
		}
	}
}
