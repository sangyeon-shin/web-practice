package action;

import java.util.Scanner;

import svc.MemberDeleteService;
import util.ConsoleUtil;
import vo.Member;

public class MemberDeleteAction implements Action {

	@Override
	public void execute(Scanner sc) throws Exception {
		ConsoleUtil cu = new ConsoleUtil();
		Member deleteMember = cu.getDeleteMember(sc);
		
		MemberDeleteService memberDeleteService = new MemberDeleteService();
		
		boolean isDeleteSuccess = memberDeleteService.deleteMember(deleteMember);
		if(isDeleteSuccess) {
			System.out.println("ȸ�� ���� ���� ����");
		}else {
			System.out.println("ȸ�� ���� ���� ����");
		}
		
	}

}
