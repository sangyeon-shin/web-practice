package action;

import java.util.Scanner;

public interface Action {
	
	void execute(Scanner sc)throws Exception;
	
}
