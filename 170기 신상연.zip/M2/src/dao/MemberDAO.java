package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static db.JdbcUtil.*;

import vo.Member;

public class MemberDAO {
	Connection con;

	public MemberDAO(Connection con) {
		this.con = con;
	}

	public int insertNewMember(Member newMember) {
		int insertCount = 0;
		PreparedStatement pstmt = null;

		String sql = "INSERT INTO member VALUES(member_id_seq.nextval,?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, newMember.getName());
			pstmt.setString(2, newMember.getAddr());
			pstmt.setString(3, newMember.getNation());
			pstmt.setString(4, newMember.getEmail());
			pstmt.setInt(5, newMember.getAge());
			insertCount = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					close(pstmt);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return insertCount;
	}

	/*******************************************************************************/

	public void showMember(Member printMember) {
		ResultSet rs = null;
		// int printCount = 0;
		PreparedStatement pstmt = null;

		String sql = "SELECT * FROM member";
		try {
			pstmt = con.prepareStatement(sql);

			rs = pstmt.executeQuery();
			System.out.println(sql);
			while (rs.next()) {
				System.out.print("ID: " + rs.getString(1));
				System.out.print(", NAME: " + rs.getString(2));
				System.out.print(", ADDR: " + rs.getString(3));
				System.out.print(", NATION: " + rs.getString(4));
				System.out.print(", EMAIL: " + rs.getString(5));
				System.out.println(", AGE: " + rs.getInt(6));
				System.out.println();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					close(pstmt);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// return printCount;
	}

	/**
	 * @return ****************************************************************************************************/
	public int updateMember(Member updateMember) {
		int updateCount = 0;
		PreparedStatement pstmt = null;
		
		String sql = "UPDATE member SET name = ? , addr = ? , nation = ? ,email = ? , age = ? WHERE name = ?";
				
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, updateMember.getChangedname());
			pstmt.setString(2, updateMember.getAddr());
			pstmt.setString(3, updateMember.getNation());
			pstmt.setString(4, updateMember.getEmail());
			pstmt.setInt(5, updateMember.getAge());
			pstmt.setString(6, updateMember.getName());
			
			updateCount = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null)
					close(pstmt);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return updateCount;
	}
	/**************************************************************************************************************/
	public  int deleteMember(Member deleteMember) {
		int deleteCount = 0;
		PreparedStatement pstmt = null;
		
		String sql = "DELETE MEMBER WHERE NAME = ?";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, deleteMember.getName());
			deleteCount = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null)
					close(pstmt);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return deleteCount;
	}
	
	/***********************************************************************************************************/
}
