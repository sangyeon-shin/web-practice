package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static db.JdbcUtil.*;

import vo.Member;

public class MemberDAO {
	Connection con;
	
	public MemberDAO(Connection con) {
		this.con = con;
	}
	
	public int insertNewMember(Member newMember) {
		int insertCount = 0;
		PreparedStatement pstmt = null;
		
		String sql = "INSERT INTO member VALUES(member_id_seq.nextval,?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, newMember.getName());
			pstmt.setString(2, newMember.getAddr());
			pstmt.setString(3, newMember.getNation());
			pstmt.setString(4, newMember.getEmail());
			pstmt.setInt(5, newMember.getAge());
			insertCount = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null)
					close(pstmt);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return insertCount;
	}
	/*******************************************************************************/
	
	public void showMember(Member printMember) {
		ResultSet rs = null;
		//int printCount = 0;
		PreparedStatement pstmt = null;
		
		String sql = "SELECT * FROM member";
		try {
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			System.out.println(sql);
			while(rs.next()) {
				System.out.print("id: "+rs.getString(1));
				System.out.print(", name: "+rs.getString(2));
				System.out.print(", addr: "+rs.getString(3));
				System.out.print(", nation: "+rs.getString(4));
				//System.out.println(", age: "+rs.getInt(5));
				System.out.println();
				
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt !=null)
					close(pstmt);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		//return printCount;
	}

	
}
