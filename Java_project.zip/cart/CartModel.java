package cart;

import java.io.Serializable;

import protein.ProteinModel;

public class CartModel implements Serializable{
	ProteinModel proteins;
	int count;
	int total;
	
	//생성자
	public CartModel(){
		this(null,0);
	}
	public CartModel(ProteinModel proteins,int count){
		this.proteins = proteins;
		this.count = count;
	}
	public void setAll(ProteinModel proteins, int count) {
		this.proteins = proteins;
		this.count = count;
	}
	
	//getter와 setter들
	public ProteinModel getProteins() {
		return proteins;
	}
	public void setProteins(ProteinModel proteins) {
		this.proteins = proteins;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	//hashCode와 equals	
	@Override
	public boolean equals(Object o) {
		if (o instanceof CartModel) {
			CartModel c = (CartModel) o;
			if(this.proteins.equals(c.proteins))
				return true;
		}
		return false;		
	}
	
	
	public void infoPrint() {
		System.out.println(proteins + "\t" + count);
	}
	
	

}
