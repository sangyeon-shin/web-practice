package cart;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

import protein.ProteinModel;

public class CartController implements Serializable{
	
	public ArrayList<CartModel> ct;
	
	
	//생성자
	public CartController(ArrayList<CartModel> list) {
		this.ct = list;
	}
	
	//꽉차있는지 확인
	public int getSize() {
		return ct.size();
	}
	
	//	
	public void insert(CartModel c) {
		ct.add(c);
	}
	public void remove(CartModel c) {
		ct.remove(c);
	}
	
	public void clear() {
		ct.clear();
	}
	
	
	public CartModel getLocate(int num) {
		return ct.get(num);
	}

}
