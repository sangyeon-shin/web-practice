package main;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

import cart.CartController;
import cart.CartModel;
import protein.ProteinController;
import protein.ProteinModel;

public class View implements Serializable  {
	public static Scanner sc = new Scanner(System.in);
	
	public static Scanner getScanner() {
		return sc;
	}
	
	ProteinModel pt = new ProteinModel();
	CartModel ct = new CartModel();
	
/*------------------  메뉴선택 ------------------------*/
	int getUserSelect() {
		System.out.print("번호를 입력해주세요 >> ");
		int sel = Integer.parseInt(sc.next());
		sc.nextLine();
		return sel;
	}
	
	
/*------------------  관리자 main------------------------*/
	
	public void mainView(ProteinController pt)  throws IOException, ClassNotFoundException {
		
		while(true) {
			System.out.println("=======================");
			System.out.println("1. 프로틴 재고 입력");
			System.out.println("2. 프로틴 재고 수정");
			System.out.println("3. 프로틴 재고 삭제");
			System.out.println("4. 프로틴 재고 검색");
			System.out.println("5. 프로틴 재고 전체 출력");
			System.out.println("6. 돌아가기");
			System.out.println("=======================");
			mainMenuCT(pt);
		}
	}
	
	
	public void mainMenuCT(ProteinController pt)  throws IOException, ClassNotFoundException{
		int num = getUserSelect();
		
		switch (num) {
		case 1:
			System.out.println("프로틴 재고 입력을 시작합니다.");
			insert(pt);		// 입력메소드 호출
			mainView(pt);
			break;
			
		case 2:
			System.out.println("프로틴 재고 수정을 시작합니다.");
			edit(pt);		// 수정메소드 호출
			mainView(pt);
			break;
			
		case 3:
			System.out.println("프로틴 재고 삭제를 시작합니다.");
			remove(pt);		// 삭제 메소드 호출
			mainView(pt);
			break;
			
		case 4:
			System.out.println("프로틴 재고 검색을 시작합니다.");
			search(pt);		// 검색 메소드 호출
			mainView(pt);
			break;
			
		case 5:
			System.out.println("프로틴 재고 출력을 시작합니다.");
			printAll(pt);		// 재고 출력 메소드 호출
			mainView(pt);
			break;
			
		case 6:					//돌아가기
			Main.main(null);
			
		default:
			System.out.println("잘못 누르셨습니다.");
			mainView(pt);
			break;		
		}
	} 
	
	/*------------------Protein printAll 메소드-----------------------*/
	public void printAll(ProteinController list) {
				
		for(int i = 0; i<list.getSize(); i++) {
			list.getLocate(i).infoPrint();			
		}		
	}
	
	/*------------------Protein insert 메소드-----------------------*/
	
	public void insert(ProteinController pt)  throws IOException {
		FileSave save = new FileSave();
		System.out.print("제품명을 입력해주세요 :  ");
		String name = sc.next();					//제품명
		System.out.print("상품코드를 입력해주세요: ");
		String code = doubleCheck(pt);				//같은 상품코드 예외처리 메소드 호출
		System.out.print("상품 가격을 입력해주세요: ");
		int price = exceptionString();				// 상품 가격
		System.out.print("상품개수를 입력해주세요: ");
		int count = exceptionString();				// 상품 개수 (문자열, 음수 제외)
		ProteinModel i = new ProteinModel();
		i.setAll(name, code, price, count);
		pt.insert(i);
		save.listWriter(pt);
		
	}
	
	
	public String doubleCheck(ProteinController pt) {
		String check = "";
		boolean ds = true;
		while(ds) {
			check = sc.next();
			if (pt.getSize() == 0) {
				return check;
			} else {
				for(int i=0; i<pt.getSize(); i++) {
					if(pt.getLocate(i).getCode().equals(check)) {
						System.out.println("이미 존재하는 품번입니다.");
						System.out.println("상품코드를 다시 입력해주세요: ");
						break;
					}
					if (i == pt.getSize() -1) {
						ds = false;
					}
				}
			}			
		}
		return check;
	}
	
	public int exceptionString() {
		int num = 0;
		boolean rd = true;
		while(rd) {
			try {
				num = sc.nextInt();
				if(num<0) {
					System.out.println("0미만의 숫자는 입력이 불가합니다.");
				} else {
					rd = false;
				}
			} catch (Exception e) {
				sc.nextLine();
				System.out.println("정상적인 숫자를 입력해주세요");
				continue;
			}
		}
		return num;
	}
	
	
	/*------------------Protein edit 메소드-----------------------*/
	public void edit(ProteinController pt)  throws IOException {
		FileSave save = new FileSave();
		printAll(pt);
		System.out.print("상품코드를 입력해주세요: ");
		String code = sc.next();
		sc.nextLine();

				
			for(int i=0; i< pt.getSize(); i++) {
			if(pt.getLocate(i).getCode().equals(code)) {	
				while(true) {
				System.out.println("어떤 것을 변경하시겠습니까?");
				System.out.println("제품명(1), 상품코드(2), 가격(3), 상품개수(4), 그만하기(5)");
				String change = sc.next(); sc.nextLine();
			switch(change) {
			case "1":
				System.out.print("변경할 제품명: ");
				String name = sc.next(); 	sc.nextLine();
				pt.getLocate(i).setName(name);
				save.listWriter(pt);
				break;
			case "2":
				System.out.print("변경할 상품코드: ");
				String newCode = sc.next(); sc.nextLine();
				pt.getLocate(i).setCode(newCode);
				save.listWriter(pt);
				break;
			case "3":
				System.out.print("변경할 상품가격: ");
				int price = Integer.parseInt(sc.next()); sc.nextLine();
				pt.getLocate(i).setPrice(price);
				save.listWriter(pt);
				break;
			case "4":
				System.out.print("변경할 상품개수: ");
				int count = Integer.parseInt(sc.next()); sc.nextLine();
				pt.getLocate(i).setCount(count);
				save.listWriter(pt);
				break;
			case "5":	return;
			default: System.out.println("잘못된 값을 입력하셨습니다."); break;	}
			}
			}else if(i == pt.getSize() - 1) {
				System.out.println("찾으시는 상품코드가 없습니다.");
				edit(pt);			}
			}			
		}				
	
	/*------------------Protein remove 메소드-----------------------*/
	public void remove(ProteinController pt) throws IOException {
		FileSave save = new FileSave();
		printAll(pt);
		System.out.print("삭제하실 상품코드를 입력해주세요: ");
		String code = sc.next();
		if(pt.getSize() == 0) {
			System.out.println("아무것도 없습니다.");
			return;
		} else {
			for(int i=0; i<pt.getSize(); i++) {
				if(pt.getLocate(i).getCode().equals(code)) {
					pt.remove(pt.getLocate(i));
					System.out.println("삭제되었습니다.");
					save.listWriter(pt);
					return;
				}
				if(i == pt.getSize() -1) {
					System.out.println("찾으시는 상품코드가 없습니다.");
					remove(pt);				}
			}
		}
	}
	/*------------------Protein search 메소드-----------------------*/
	public void search(ProteinController pt) {
		boolean isTrue = true;
		while(isTrue) {
			System.out.println("원하시는 품번을 입력해주세요: ");
			String code = sc.next();
			for(int i=0; i<pt.getSize(); i++) {
				if (pt.getLocate(i).getCode().equals(code)) {
				System.out.println(pt.getLocate(i).getAll()+"\n");
				isTrue = false;
				break;
			} else {
				if(i == pt.getSize() -1) {
					System.out.println("잘못된 상품코드입니다.");		}
			}
			}
		}		
		
	}
	
	
/*------------------  손님용 main------------------------*/
	
	public void mainView(CartController ct, ProteinController pt)  throws IOException, ClassNotFoundException {
		while(true) {
			System.out.println("=======================");
			System.out.println("1. 장바구니 담기");
			System.out.println("2. 장바구니 수정");
			System.out.println("3. 장바구니 삭제");
			System.out.println("4. 장바구니 비우기");
			System.out.println("5. 장바구니 전체 출력");
			System.out.println("6. 결제하기");
			System.out.println("7. 돌아가기");
			System.out.println("=======================");
			mainMenuCT(ct, pt);
		}
	}
	
	public void mainMenuCT(CartController ct, ProteinController pt)  throws IOException, ClassNotFoundException{
		int num = getUserSelect();		
		
		switch (num) {
		case 1:
			System.out.println("장바구니 담기를 실행합니다.");
			insert(ct, pt);		// 입력메소드 호출
			mainView(ct, pt);
			break;
		case 2:
			System.out.println("장바구니를 수정합니다.");
			cEdit(ct, pt);		// 수정메소드 호출
			mainView(ct, pt);
			break;
			
					
		case 3:
			System.out.println("장바구니의 품목을 삭제합니다.");
			cRemove(ct, pt);		// 삭제 메소드 호출
			mainView(ct, pt);
			break;
			
		case 4:
			System.out.println("장바구니 전체비우기를 시작합니다.");
			cClear(ct, pt);		// 검색 메소드 호출
			mainView(ct, pt);
			break;
			
		case 5:
			System.out.println("장바구니를 전체 출력합니다.");
			printAll(ct);		// 재고 출력 메소드 호출
			mainView(ct, pt);
			break;
			
		case 6:					
			System.out.println("결제하는 창 만들기");
			break;
			
		case 7:			//돌아가기
			Main.main(null);
			
		default:
			System.out.println("잘못 누르셨습니다.");
			mainView(ct, pt);
			break;		
		}
	} 
	
	/*------------------장바구니 printAll 메소드-----------------------*/
	public void printAll(CartController list) {	
		if(list.getSize() == 0) {
			System.out.println("장바구니가 비었습니다.");
		} else {				
		for(int i = 0; i<list.getSize(); i++) {
			System.out.print(+i+". ");
			list.getLocate(i).infoPrint();			
		}		
		}
	}
	
	
	/*------------------장바구니 담기 메소드-----------------------*/	
	public void insert(CartController ct, ProteinController pt)  throws IOException {
		FileSave save = new FileSave();
		printAll(pt);
		ProteinModel p = insertCart(pt);
		System.out.print("상품개수를 입력해주세요: ");
		int count = exceptionString();				// 상품 개수 (문자열, 음수 제외)		
		
		//장바구니에 추가
		ct.insert(new CartModel(p,count));
		
		save.cListWriter(ct);
		
	}
	
	public ProteinModel insertCart(ProteinController pt) {				
		boolean isTrue = true;
		while(isTrue) {
			System.out.println("원하시는 상품의 상품코드를 입력해주세요: ");
			String code = sc.next();
			for(int i=0; i<pt.getSize(); i++) {
				if (pt.getLocate(i).getCode().equals(code)) {
				return pt.getLocate(i);				
			} else {
				if(i == pt.getSize() -1) {
					System.out.println("잘못된 상품코드입니다.");		}
			}
			}
		}
		return null;
	}
	
	/*------------------장바구니 edit 메소드-----------------------*/	
	public void cEdit(CartController ct, ProteinController pt)  throws IOException {
		FileSave save = new FileSave();
		printAll(ct);
		if(ct.getSize() == 0) return;
		
		System.out.print("변경할 제품의 인덱스를 입력해주세요: ");
		int index = sc.nextInt();
		sc.nextLine();
		
		if(index >= ct.getSize()) {
			System.out.println("잘못된 인덱스값을 입력하셨습니다.");
			cRemove(ct, pt);
		}
				
				System.out.print("변경할 상품개수: ");
				int count = Integer.parseInt(sc.next()); sc.nextLine();
				ct.getLocate(index).setCount(count);
				save.cListWriter(ct);						
			
}
	
	/*------------------장바구니 삭제 메소드-----------------------*/	
	public void cRemove(CartController ct, ProteinController pt)  throws IOException {
		FileSave save = new FileSave();
		printAll(ct);
		if(ct.getSize() == 0) return;
		
		System.out.print("삭제할 제품의 인덱스를 입력해주세요: ");
		int index = sc.nextInt();
		sc.nextLine();
		
		if(index >= ct.getSize()) {
			System.out.println("잘못된 인덱스값을 입력하셨습니다.");
			cRemove(ct, pt);
		}
		
		if(ct.getSize() == 0) {
			System.out.println("아무것도 없습니다.");
			return;
		} else {
			ct.remove(ct.getLocate(index));
					System.out.println("삭제되었습니다.");
					save.cListWriter(ct);
					return;
				}
	}
	
	/*------------------장바구니 비우기 메소드-----------------------*/
	public void cClear (CartController ct, ProteinController pt) {
		FileSave save = new FileSave();
		System.out.println("정말 장바구니를 비우시겠습니까?(y)");
		String answer = sc.nextLine();
		
		if(answer.equals("y")) {
			ct.clear();
		} else {
			return;
		}		
	}
	
	/*------------------결제시스템 만들기-----------------------*/
	

	
	
}

	
	


