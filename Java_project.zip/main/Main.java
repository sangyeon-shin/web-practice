package main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import cart.CartController;
import cart.CartModel;
import protein.ProteinController;
import protein.ProteinModel;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		View view = new View();
		FileSave save = new FileSave();
		
		ArrayList<ProteinModel> plist = new ArrayList<ProteinModel>();
		ArrayList<CartModel> clist = new ArrayList<CartModel>();
		
		//프로틴 재고 파일
		ProteinController pt = save.pListReader();
		if(pt == null) {
			pt = new ProteinController(plist);
		}
		
		//카트 파일
		CartController ct = save.cListReader();
		if(ct == null) {
			ct = new CartController(clist);
		}		
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("관리자로 로그인하고 싶으면 y입력");
		String login = sc.nextLine();
		
		if(login.equals("y")) {
		view.mainView(pt);
		} else {view.mainView(ct, pt);}
		

	}

}
