package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import cart.CartController;
import protein.ProteinController;

public class FileSave {
	
	// ************************ Proteins ***********************************
	public void listWriter(ProteinController plist) throws IOException {
		OutputStream os = new FileOutputStream("plist.plist");
		ObjectOutputStream out = new ObjectOutputStream(os);
		
		out.writeObject(plist);
		
		out.close();		
	}
	
	public ProteinController pListReader() throws IOException, ClassNotFoundException {
		
		File f = new File("plist.plist");
		if(f.isFile()) {
			InputStream is = new FileInputStream("plist.plist");
			ObjectInputStream in = new ObjectInputStream(is);
			
			ProteinController plist = (ProteinController) in.readObject();
			in.close();
			
			return plist;
		}
		else return null;
	}
	
	
	// ************************ Cart ***********************************
	public void cListWriter(CartController clist) throws IOException{
		OutputStream os = new FileOutputStream("clist.clist");
		ObjectOutputStream out = new ObjectOutputStream(os);
		
		out.writeObject(clist);
		out.close();
	}
	
	public CartController cListReader() throws IOException, ClassNotFoundException{
		
		File f = new File("clist.clist");
		if(f.isFile()) {
			InputStream is = new FileInputStream("clist.clist");
			ObjectInputStream in = new ObjectInputStream(is);
			
			CartController clist = (CartController) in.readObject();
			in.close();
			
			return clist;
		}
		else return null;
	}

}
