package protein;

import java.io.Serializable;

public class ProteinModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	private String name;	//이름
	private String code;	//시리얼넘버
	private int price;		//가격
	private int count;		//품목갯수
	
	public ProteinModel (){
		this("","",0,0);
	}
	
	public ProteinModel(String name, String code, int price, int count) {
		this.name = name;
		this.code = code;
		this.price = price;
		this.count = count;		
	}
	
	public void setAll(String name, String code, int price, int count) {
		this.name = name;
		this.code = code;
		this.price = price;
		this.count = count;	
	}
	
	
	//getter와 setter들
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}	
	
	public boolean equals(Object o) {
		if (o instanceof ProteinModel) {
			ProteinModel p = (ProteinModel) o;
			if (this.name.equals(p.name))
				return true;
		}
		return false;
	}
	
	public void infoPrint() {
		System.out.println(name + "\t\t" + code + "\t" + price + "\t" + count);
	}
	
	public String getAll() {
		return name + " "  + code + " " + price + " " + count;
	}
	
	@Override
	public String toString() {
		return name + "\t\t" + price;
	}
	

	
	

}
