package protein;

import java.io.Serializable;
import java.util.ArrayList;

public class ProteinController implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public ArrayList<ProteinModel> pt;
	//main에서 입력받은 값들 받기
	
	//생성자
	public ProteinController(ArrayList<ProteinModel> list) {
		this.pt = list;
	}
	
	//꽉차있는지 확인
	public int getSize() {
		return pt.size();
	}
	
	//입력하기
	public void insert(ProteinModel p){
		pt.add(p);		
	}
	
	// 지우기
	public void remove(ProteinModel p){
		pt.remove(p);
	}
	
	public ProteinModel getLocate(int num) {
		return pt.get(num);
	}
	
	
	
}
