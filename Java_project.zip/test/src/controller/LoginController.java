package controller;

import java.io.Serializable;
import java.util.ArrayList;
import vo.Login;
import vo.Memo;


public class LoginController implements Serializable {
	public ArrayList<Login> mm;
	
	public LoginController(ArrayList<Login> loginlist) {
		this.mm = loginlist;
	}
	public int getSize() {
		return mm.size();
	}
	public void insert(Login m) {
		mm.add(m);
	}
	public void remove(Login m) {
		mm.remove(m);
	}
	public Login getLocate(int num) {
		return mm.get(num);
	}
}
