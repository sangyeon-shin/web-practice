package controller;

import java.io.Serializable;
import java.util.ArrayList;

import vo.Note;

public class NoteController implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	public ArrayList<Note> mm;
	
	public NoteController(ArrayList<Note> notelist) {
		this.mm = notelist;
	}
	public int getSize() {
		return mm.size();
	}
	public void insert(Note m) {
		mm.add(m);
	}
	public void remove(Note m) {
		mm.remove(m);
	}
	public Note getLocate(int num) {
		return mm.get(num);
	}
}
