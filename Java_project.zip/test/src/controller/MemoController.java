package controller;

import java.io.Serializable;
import java.util.ArrayList;

import vo.Memo;

public class MemoController implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ArrayList<Memo> mm;
	
	public MemoController(ArrayList<Memo> memolist) {
		this.mm = memolist;
	}
	public int getSize() {
		return mm.size();
	}
	public void insert(Memo m) {
		mm.add(m);
	}
	public void remove(Memo m) {
		mm.remove(m);
	}
	public Memo getLocate(int num) {
		return mm.get(num);
	}
}
