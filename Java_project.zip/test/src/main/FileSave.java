package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import controller.*;


public class FileSave {
	public void memoWriter(MemoController memolist) throws IOException{
		
		OutputStream os = new FileOutputStream("memolist.memolist");
		ObjectOutputStream out = new ObjectOutputStream(os);
		
		out.writeObject(memolist);
		
		out.close();
	}
	
	MemoController memolistReader() throws IOException, ClassNotFoundException{
		
		File f = new File("memolist.memolist");
		if(f.isFile()) {
			InputStream is = new FileInputStream("memolist.memolist");
			ObjectInputStream in = new ObjectInputStream(is);
			
			MemoController memolist = (MemoController) in.readObject();
			in.close();
			
			return memolist;
		}
		else
			return null;
	}
	/*********************************************************************************/
	public void noteWriter(NoteController notelist) throws IOException{
		
		OutputStream os = new FileOutputStream("notelist.notelist");
		ObjectOutputStream out = new ObjectOutputStream(os);
		
		out.writeObject(notelist);
		
		out.close();
	}
	
	NoteController notelistReader() throws IOException, ClassNotFoundException{
		
		File f = new File("notelist.notelist");
		if(f.isFile()) {
			InputStream is = new FileInputStream("notelist.notelist");
			ObjectInputStream in = new ObjectInputStream(is);
			
			NoteController notelist = (NoteController) in.readObject();
			in.close();
			
			return notelist;
		}
		else
			return null;
	}
	/********************************************************************************************/
	public void loginWriter(LoginController loginlist) throws IOException{
		
		OutputStream os = new FileOutputStream("loginlist.loginlist");
		ObjectOutputStream out = new ObjectOutputStream(os);
		
		out.writeObject(loginlist);
		
		out.close();
	}
	
	LoginController loginlistReader() throws IOException, ClassNotFoundException{
		
		File f = new File("loginlist.loginlist");
		if(f.isFile()) {
			InputStream is = new FileInputStream("loginlist.loginlist");
			ObjectInputStream in = new ObjectInputStream(is);
			
			LoginController loginlist = (LoginController) in.readObject();
			in.close();
			
			return loginlist;
		}
		else
			return null;
	}
	
}
