package main;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import controller.*;
import vo.Login;
import vo.Memo;
import vo.Note;

public class View {

	/**
	 * 
	 */
	public static Scanner sc = new Scanner(System.in);

	Memo memo = new Memo();
	Login login = new Login();
	Note note = new Note();

	public void LoginMenu(LoginController login, MemoController memo, NoteController note) throws IOException {
		while (true) {
			System.out.print("오늘 날짜:\t");
			java.sql.Date today = new java.sql.Date(System.currentTimeMillis());
			System.out.print(today);
			System.out.println("\t 제작자: 신상연");
			System.out
					.println("==========================================로그인메뉴========================================");
			System.out.println("1. 로그인\t\t2. 회원가입\t\t3.아이디 찾기");
			System.out.println(
					"==========================================================================================");
			String input = sc.next();

			switch (input) {
			case "1":
				Login(login, memo, note);
				break;
			case "2":
				lInsert(login, memo, note);
				break;
			case "3":
				lIDCheck(login);
				break;
			default: {
				System.out.println("잘못 입력하셨습니다.");
			}
			}
		}
	}

	public void Login(LoginController login, MemoController memo, NoteController note) throws IOException {
		//String admin = "관리자";
		System.out.println("아이디를 입력해주세요.");
		String ID = sc.next();
		System.out.println("비밀번호를 입력해주세요.");
		String PW = sc.next();

		for (int i = 0; i < login.getSize(); i++) {
			if (login.getLocate(i).getID().equals(ID.toLowerCase())
					&& login.getLocate(i).getPW().equals(PW)) {

				if (login.getLocate(i).getID().equals("관리자")
						&& login.getLocate(i).getPW().equals(PW)) {
					System.out.println("관리자 로그인 성공!");
					AdminMenu(login);
				}

				else {
					System.out.println(login.getLocate(i).getID() + "님 환영합니다.");
					MainMenu(memo, note);
				}
			}
		}
		

	}

	public void AdminMenu(LoginController login) throws IOException {
		System.out.println("==========================================관리자===========================================");
		System.out.println("1. 회원 정보 수정");
		System.out.println("2. 회원 삭제");
		System.out.println("3. 전체 회원 출력");
		System.out.println("4. 로그인메뉴로");
		System.out
				.println("==========================================================================================");
		AdminMenusel(login);
	}

	public void AdminMenusel(LoginController login) throws IOException {
		int num = getUserSelect();

		switch (num) {
		case 1:
			lEdit(login);
			AdminMenu(login);
			break;
		case 2:
			lRemove(login);
			AdminMenu(login);
			break;
		case 3:
			lPrintAll(login);
			AdminMenu(login);
			break;
		case 4:
			return;
		default:

			System.out.println("잘못 입력하셨습니다.");

		}

	}

	public String lIDCheck(LoginController login) throws IOException {

		System.out.println("★아이디찾기");
		System.out.println("주민등록번호를 입력해주세요.");

		String check = sc.next();
		boolean ds = true;
		while (ds) {
			if (login.getSize() == 0) {

				System.out.println("아이디 필드 존재하지 않음");

				return check;
			} else if (login.getSize() != 0) {
				for (int i = 0; i < login.getSize(); i++) {
					if (login.getLocate(i).getNum().toLowerCase().contentEquals(check.toLowerCase())) {

						System.out.println("찾으시는 아이디는 " + login.getLocate(i).getID());

						ds = false;
						break;
					}
					if (i == login.getSize() - 1) {
						ds = false;
					}
				}
			} else

				System.out.println("잘못 입력하셨습니다.");

			ds = false;
			break;
		}
		return check;
	}

	public void lInsert(LoginController login, MemoController memo, NoteController note) throws IOException {
		FileSave save = new FileSave();

		System.out.print("아이디를 입력해주세요: ");
		String ID = sc.next();
		System.out.print("비밀번호를 입력해주세요: ");
		String PW = sc.next();
		System.out.print("주민등록번호를 입력해주세요: ");
		String Num = sc.next();

		Login i = new Login();
		i.setAll(ID, PW, Num);
		login.insert(i);
		save.loginWriter(login);
	}

	public void lEdit(LoginController login) throws IOException {
		FileSave save = new FileSave();
		lPrintAll(login);
		System.out.print("주민등록번호를 입력해주세요.");
		String Num = sc.next();
		for (int i = 0; i < login.getSize(); i++) {
			if (login.getLocate(i).getNum().toLowerCase().equals(Num.toLowerCase())) {
				System.out.print("변경할 아이디: ");
				sc.nextLine();
				String lID = sc.nextLine();
				login.getLocate(i).setID(lID);
				System.out.print("변경할 비밀번호: ");
				String lPW = sc.next();
				login.getLocate(i).setPW(lPW);
				System.out.print("변경할 주민등록번호: ");
				String lnum = sc.next();
				login.getLocate(i).setNum(lnum);
				System.out.print("변경되었습니다.");
				System.out.println();
				save.loginWriter(login);
				break;
			} else if (i == login.getSize() - 1) {
				System.out.println("찾으시는 아이디가 없습니다.");
				lEdit(login);
			}
		}
	}

	public void lRemove(LoginController login) throws IOException {
		FileSave save = new FileSave();
		lPrintAll(login);
		System.out.print("삭제하실 아이디의 주민번호를 입력해주세요:");
		String lNum = sc.next();
		if (login.getSize() == 0) {
			System.out.println("회원이 없습니다.");
			return;
		} else {
			for (int i = 0; i < login.getSize(); i++) {
				if (login.getLocate(i).getNum().toLowerCase().equals(lNum.toLowerCase())) {
					login.remove(login.getLocate(i));
					System.out.print("삭제 되었습니다.");
					System.out.println();
					save.loginWriter(login);
					return;
				}
				if (i == login.getSize() - 1) {
					System.out.println("찾으시는 아이디가 없습니다.");
					lRemove(login);
				}
			}
		}
	}

	/*
	 * public void lSearch(LoginController login) throws IOException{ boolean isTrue
	 * = true; while(isTrue) { System.out.println("검색할 아이디의 주민번호를 업력해주세요: "); String
	 * lNum = sc.next(); for(int i = 0; i<login.getSize(); i++) {
	 * if(login.getLocate(i).getNum().toLowerCase().equals(lNum.toLowerCase())) {
	 * System.out.println(login.getLocate(i).getAll() + "\n"); isTrue = false;
	 * break; }else { if(i == login.getSize() -1) {
	 * System.out.println("잘못된 단어입니다."); } } } } }
	 */
	public void lPrintAll(LoginController list) throws IOException { // 전체출력
		ArrayList<Login> loginlist = new ArrayList<Login>();
		System.out.println();
		loginlist.addAll(list.mm); // list.at를 사용하려면 AccModel 클래스를 퍼블릭으로 해줘야함.
		System.out.println();

		System.out.println("[아이디]\t\t[비밀번호]\t\t[주민등록번호]");
		for (int i = 0; i < loginlist.size(); i++) { // 깊은 복사
			loginlist.get(i).infoPrint();
		}

	}

	/**********************************************************************************************************************/
	public void MainMenu(MemoController memo, NoteController note) throws IOException {
		System.out.println("==========================================메인메뉴==========================================");
		System.out.println("1. 단어장");
		System.out.println("2. 메모장");
		System.out.println("3. 로그아웃");
		System.out
				.println("==========================================================================================");
		MainMenusel(memo, note);

	}

	public void MainMenusel(MemoController memo, NoteController note) throws IOException {
		int num = getUserSelect();

		switch (num) {
		case 1:
			SubMenu1(memo);
			break;
		case 2:
			SubMenu2(note);
			break;
		case 3:
			return;
		default:
			System.out.println("잘못 입력하셨습니다.");
		}

	}

	public void SubMenu1(MemoController memo) throws IOException {
		System.out.println("==========================================MemoJJang========================================");
		System.out.println("1. 단어 추가");
		System.out.println("2. 단어 수정");
		System.out.println("3. 단어 제거");
		System.out.println("4. 단어 검색");
		System.out.println("5. 전체 단어 출력");
		System.out.println("6. 메인메뉴로");
		System.out
				.println("==========================================================================================");
		SubMenuSel(memo);
		
	}

	public void SubMenuSel(MemoController memo) throws IOException {
		int num = getUserSelect();

		switch (num) {
		case 1:
			mInsert(memo);
			SubMenu1(memo);
			break;
		case 2:
			mEdit(memo);
			SubMenu1(memo);
		case 3:
			mRemove(memo);
			SubMenu1(memo);
		case 4:
			mSearch(memo);
			SubMenu1(memo);
		case 5:
			mPrintAll(memo);
			SubMenu1(memo);
		case 6:
			return;
		default:
			System.out.println("잘못 누르셨습니다.");
			SubMenu1(memo);
			break;
		}

	}

	public int getUserSelect() {
		System.out.println("번호를 입력해주세요>");
		int sel = sc.nextInt();
		return sel;
	}

	public void mInsert(MemoController memo) throws IOException {
		FileSave save = new FileSave();
		System.out.print("넘버 코드를 입력해주세요: ");
		String code = mNumberCheck(memo);
		System.out.print("영단어를 입력해주세요: ");
		String english = mEnglishCheck(memo);
		System.out.print("뜻 입력해주세요: ");
		String korean = sc.next();
		Memo i = new Memo();
		i.setAll(code, english, korean);
		memo.insert(i);
		save.memoWriter(memo);
	}

	public String mEnglishCheck(MemoController memo) throws IOException {
		String check = "";
		boolean ds = true;
		while (ds) {
			check = sc.next();
			if (memo.getSize() == 0) {
				return check;
			} else {
				for (int i = 0; i < memo.getSize(); i++) {
					if (memo.getLocate(i).getEnglish().toLowerCase().equals(check.toLowerCase())) {
						System.out.println("이미 존재하는 영단어입니다.");
						System.out.println("다른 영단어를 입력해주세요.");
						break;
					}
					if (i == memo.getSize() - 1) {
						ds = false;
					}
				}
			}
		}
		return check;
	}

	public String mNumberCheck(MemoController memo) throws IOException {
		String check = "";
		boolean ds = true;
		while (ds) {
			check = sc.next();
			if (memo.getSize() == 0) {
				return check;
			} else {
				for (int i = 0; i < memo.getSize(); i++) {
					if (memo.getLocate(i).getCode().equals(check)) {
						System.out.println("이미 존재하는 넘버 코드입니다.");
						System.out.println("다른 넘버 코드를 입력해주세요.");
						break;
					}
					if (i == memo.getSize() - 1) {
						ds = false;
					}
				}
			}
		}
		return check;
	}

	public void mEdit(MemoController memo) throws IOException {
		FileSave save = new FileSave();
		mPrintAll(memo);
		System.out.print("영단어를 입력해주세요.");
		String english = sc.next();
		for (int i = 0; i < memo.getSize(); i++) {
			if (memo.getLocate(i).getEnglish().toLowerCase().equals(english.toLowerCase())) {
				System.out.print("변경할 영단어: ");
				sc.nextLine();
				String eenglish = sc.nextLine();
				memo.getLocate(i).setEnglish(eenglish);
				System.out.print("변경할 뜻: ");
				String kkorean = sc.next();
				memo.getLocate(i).setKorean(kkorean);
				System.out.print("변경할 코드: ");
				String ccode = sc.next();
				memo.getLocate(i).setCode(ccode);
				System.out.print("변경되었습니다.");
				System.out.println();
				save.memoWriter(memo);
				break;
			} else if (i == memo.getSize() - 1) {
				System.out.println("찾으시는 단어가 없습니다.");
				mEdit(memo);
			}
		}
	}

	public void mRemove(MemoController memo) throws IOException {
		FileSave save = new FileSave();
		mPrintAll(memo);
		System.out.print("삭제하실 영단어를 입력해주세요:");
		String eenglish = sc.next();
		if (memo.getSize() == 0) {
			System.out.println("단어가 없습니다.");
			return;
		} else {
			for (int i = 0; i < memo.getSize(); i++) {
				if (memo.getLocate(i).getEnglish().toLowerCase().equals(eenglish.toLowerCase())) {
					memo.remove(memo.getLocate(i));
					System.out.print("삭제 되었습니다.");
					System.out.println();
					save.memoWriter(memo);
					return;
				}
				if (i == memo.getSize() - 1) {
					System.out.println("찾으시는 단어가 없습니다.");
					mRemove(memo);
				}
			}
		}
	}

	public void mSearch(MemoController memo) throws IOException {
		boolean isTrue = true;
		while (isTrue) {
			System.out.println("검색할 단어를 업력해주세요: ");
			String eenglish = sc.next();
			for (int i = 0; i < memo.getSize(); i++) {
				if (memo.getLocate(i).getEnglish().toLowerCase().equals(eenglish.toLowerCase())) {
					System.out.println(memo.getLocate(i).getAll() + "\n");
					isTrue = false;
					break;
				} else {
					if (i == memo.getSize() - 1) {
						System.out.println("잘못된 단어입니다.");
					}
				}
			}
		}
	}

	public void mPrintAll(MemoController list) throws IOException { // 전체출력
		ArrayList<Memo> memolist = new ArrayList<Memo>();
		System.out.println();
		memolist.addAll(list.mm); // list.at를 사용하려면 AccModel 클래스를 퍼블릭으로 해줘야함.
		System.out.println();

		System.out.println("[번호]\t\t[영단어]\t\t[뜻]");
		for (int i = 0; i < memolist.size(); i++) { // 깊은 복사
			memolist.get(i).infoPrint();
		}

	}

	/*************************************************************************************************************/
	public void SubMenu2(NoteController note) throws IOException {
		System.out.println("==============================================메모장=======================================");
		System.out.println("1. 메모 추가\t2.메모 수정\t3.메모 제거\t4.메모 출력\t5.메인메뉴로");
		System.out
				.println("==========================================================================================");
		nPrintAll(note);
		System.out.print(">");
		SubMenuSel2(note);
	}

	public void SubMenuSel2(NoteController note) throws IOException {
		int num = getUserSelect();

		switch (num) {
		case 1:
			nInsert(note);
			SubMenu2(note);
			break;
		case 2:
			nEdit(note);
			SubMenu2(note);
		case 3:
			nRemove(note);
			SubMenu2(note);
		case 4:
			nPrintAll(note);
			SubMenu2(note);
		case 5:
			return;
		default:
			System.out.println("잘못 누르셨습니다.");
			SubMenu2(note);
			break;
		}

	}

	public void nInsert(NoteController note) throws IOException {
		FileSave save = new FileSave();
		System.out.print("입력해주세요: ");
		String str = sc.next();

		Note i = new Note();
		i.setAll(str);
		note.insert(i);
		save.noteWriter(note);
	}
	/*
	 * public String nStrCheck(NoteController note) throws IOException{ String check
	 * = ""; boolean ds= true; while(ds) { check = sc.next(); if(note.getSize() ==
	 * 0) { return check; }else { for(int i=0; i<note.getSize(); i++) {
	 * if(note.getLocate(i).getEnglish().toLowerCase().equals(check.toLowerCase()))
	 * { System.out.println("이미 존재하는 영단어입니다.");
	 * System.out.println("다른 영단어를 입력해주세요."); break; } if(i == note.getSize() -1) {
	 * ds = false; } } } } return check; }
	 */

	public void nEdit(NoteController note) throws IOException {
		FileSave save = new FileSave();
		// nPrintAll(memo);
		System.out.print("수정할 단어를 입력해주세요.");
		String str = sc.next();
		for (int i = 0; i < note.getSize(); i++) {
			if (note.getLocate(i).getStr().equals(str)) {
				System.out.print("변경할 단어: ");
				sc.nextLine();
				String str1 = sc.nextLine();
				note.getLocate(i).setStr(str1);
				System.out.print("변경되었습니다.");
				System.out.println();
				save.noteWriter(note);
				break;
			} else if (i == note.getSize() - 1) {
				System.out.println("찾으시는 단어가 없습니다.");
				nEdit(note);
			}
		}
	}

	public void nRemove(NoteController note) throws IOException {
		FileSave save = new FileSave();
		nPrintAll(note);
		System.out.print("삭제하실 영단어를 입력해주세요:");
		String str = sc.next();
		if (note.getSize() == 0) {
			System.out.println("단어가 없습니다.");
			return;
		} else {
			for (int i = 0; i < note.getSize(); i++) {
				if (note.getLocate(i).getStr().equals(str)) {
					note.remove(note.getLocate(i));
					System.out.print("삭제 되었습니다.");
					System.out.println();
					save.noteWriter(note);
					return;
				}
				if (i == note.getSize() - 1) {
					System.out.println("찾으시는 단어가 없습니다.");
					nRemove(note);
				}
			}
		}
	}

	/*
	 * public void nSearch(NoteController note) throws IOException{ boolean isTrue =
	 * true; while(isTrue) { System.out.println("검색할 단어를 업력해주세요: "); String str =
	 * sc.next(); for(int i = 0; i<note.getSize(); i++) {
	 * if(note.getLocate(i).getStr().equals(str)) {
	 * System.out.println(note.getLocate(i).getAll() + "\n"); isTrue = false; break;
	 * }else { if(i == note.getSize() -1) { System.out.println("잘못된 단어입니다."); } } }
	 * } }
	 */
	public void nPrintAll(NoteController note) throws IOException { // 전체출력
		ArrayList<Note> notelist = new ArrayList<Note>();
		notelist.addAll(note.mm); // list.at를 사용하려면 AccModel 클래스를 퍼블릭으로 해줘야함.
		for (int i = 0; i < notelist.size(); i++) { // 깊은 복사
			notelist.get(i).infoPrint();
		}
	}
	/***********************************************************************************************/

}
