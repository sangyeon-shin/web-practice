package main;

import java.util.ArrayList;
import java.io.*;
import controller.*;
import vo.*;

public class Main {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		View view = new View();
		FileSave save = new FileSave();
		
		ArrayList<Memo> memolist = new ArrayList<Memo>();
		ArrayList<Note> notelist = new ArrayList<Note>();
		ArrayList<Login> loginlist = new ArrayList<Login>();
		
		MemoController memo = save.memolistReader();
		if(memo == null) {
			memo = new MemoController(memolist);
			save.memoWriter(memo);
		}
		NoteController note = save.notelistReader();
		if(note == null) {
			note = new NoteController(notelist);
			save.noteWriter(note);
		}
		LoginController login = save.loginlistReader();
		if(login == null) {
			login = new LoginController(loginlist);
			save.loginWriter(login);
		}
		view.LoginMenu(login, memo, note);
	}
}
