package vo;

import java.io.Serializable;



public class Login implements Serializable {
	/******************************************************************************************/
	private String ID;
	private String PW;
	private String num;
	
	public Login() {
		this("","","");
	}
	public Login(String ID,String PW,String num) {
		this.ID = ID;
		this.PW = PW;
		this.num = num;
	}
	public void setLogin(String ID,String PW,String num) {
		this.ID = ID;
		this.PW = PW;
		this.num = num;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPW() {
		return PW;
	}
	public void setPW(String pW) {
		PW = pW;
	}
	public String getAll() {
		return ID + " " + PW + " " + num;
	}
	public void setAll(String ID,String PW,String num) {
		this.ID = ID;
		this.PW = PW;
		this.num = num;
	}
	public void infoPrint() {
		System.out.println(ID + "\t\t" + PW + "\t\t " + num);
	}
	public boolean equals(Object o) {
		if (o instanceof Login) {
			Login a = (Login) o;
			if (this.ID.equals(a.ID))
				return true;
		}
		
		return false;
	}
	
	/*******************************************************************************************/
}
