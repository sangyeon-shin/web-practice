package vo;

import java.io.Serializable;

public class Memo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
	private String english;
	private String korean;
	
	public Memo(){
		this("","","");
	}
	public Memo(String code,String english,String korean){
		this.code = code;
		this.english = english;
		this.korean = korean;
	}
	public void setmemo(String code,String english,String korean){
		this.code = code;
		this.english = english;
		this.korean = korean;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getEnglish() {
		return english;
	}
	public void setEnglish(String english) {
		this.english = english;
	}
	public String getKorean() {
		return korean;
	}
	public void setKorean(String korean) {
		this.korean = korean;
	}
	public String getAll() {
		return code + " " + english + " " + korean;
	}
	public void setAll(String code, String english, String korean) {
		this.code = code;
		this.english = english;
		this.korean = korean;
	}
	public void infoPrint() {
		System.out.println(code + "\t\t" + english + "\t\t " + korean);
	}
	public boolean equals(Object o) {
		if (o instanceof Memo) {
			Memo a = (Memo) o;
			if (this.english.equals(a.english))
				return true;
		}
		return false;
	}
}
