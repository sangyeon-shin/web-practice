package vo;

import java.io.Serializable;

public class Note implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private String str;
	
	
	public Note(){
		this("");
	}
	public Note(String str){
		this.str = str;
		
	}
	public void setNote(String str) {
		this.str = str;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public String getAll() {
		return str;
	}
	public void setAll(String str) {
		this.str = str;
	}
	public void infoPrint() {
		System.out.println(str);
	}
	public boolean equals(Object o) {
		if (o instanceof Note) {
			Note a = (Note) o;
			if (this.str.equals(a.str))
				return true;
		}
		return false;
	}
}
