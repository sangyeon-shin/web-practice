<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Main_model extends CI_model {

    function __construct(){
        parent::__construct();
        //database.php 파일에서 $test(database이름)['test(table이름)'] 설정값 load
        $this->test = $this->load->database('default', TRUE);
    }

    function register($store_name,$classification,$address,$phone) {
        // Database에 전달 받은 가게정보 저장
        $query = $this->test->query("INSERT INTO store(store_name, classification, address, phone) 
        VALUES('$store_name', '$classification', '$address', '$phone')");
        
    }

    function store_list(){
        // Database에 저장된 전체 가게정보 로드
        $query = $this->test->query("select * from store");
        foreach ($query->result_array() as $row){
            echo '가게이름 : ', $row['store_name'];
            echo '<br>';
            echo '분류 : ', $row['classification'];
            echo '<br>';
            echo '주소 : ', $row['address'];
            echo '<br>';
            echo '번호 : ', $row['phone'];
            echo '<br>';
        }
    }
}