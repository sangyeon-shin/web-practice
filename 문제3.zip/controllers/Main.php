<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

    function __construct() {
        parent::__construct();

    }

    //main 함수 => "URL/index.php/main" 로 설정
    public function main() {
        
        $this->load->view('main');
    }

    public function store_list(){
        // $this->load->view : /application/views 폴더를 탐색 후 store_list.php 뷰 출력
        $this->load->view('store_list');
    }

    public function store_detail(){
        // $this->load->view : /application/views 폴더를 탐색 후 store_detail.php 뷰 출력
        $this->load->view('store_detail');
    }

    public function owner_page(){
        // $this->load->view : /application/views 폴더를 탐색 후 owner_page.php 뷰 출력
        $this->load->view('owner_page');

        // model('[modelfile]') : model에는 /application/models에 있는 Main_model.php를 설정  
        // $this->Main_model->store_list();는 로드된 Main_model.php의 store_list 함수를 실행
        $this->load->model('Main_model');
        $result = $this->Main_model->store_list();
        
    }
    
    public function owner_page2(){
        // $this->load->view : /application/views 폴더를 탐색 후 owner_page2.php 뷰 출력
        $this->load->view('owner_page2');
    }

    public function add_store(){
        // $this->load->view : /application/views 폴더를 탐색 후 add_store.php 뷰 출력
        $this->load->view('add_store');
    }

    public function add_store_submit(){
        // add_store.php에서 FORM 형식을 이용해서 get형식으로 데이터를 받아서 model로 전달 후 DB에 저장
        $store_name = $this->input->get('store_name');
        $classification = $this->input->get('classification');
        $address = $this->input->get('address');
        $phone = $this->input->get('phone');
        
        $this->load->model('Main_model');
        $this->Main_model->register($store_name,$classification,$address,$phone);
    }
}