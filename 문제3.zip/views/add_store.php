<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>신상닷컴</title>
  <style>
    section{
      text-align: center;
    }
    form{
      text-align: left;
    }
    .formBox{
      position: absolute;
      left: 50%;
        transform: translate(-50%, 10px);
    }
    form span{
      display: inline-block;
      width: 120px;
      text-align: right;
      margin-right: 10px;
    }

    form div{
      margin: 6px;
    }

    select{
      height: 25px;
    }

  </style>
</head>
<body>
  <section>
    <a href="/ci/index.php/Main/main"><h1>신상닷컴</h1></a>
    <div class="formBox">
      <form action="/ci/index.php/Main/add_store_submit">

      <div>
        <span>가게이름:</span>
        <input name="store_name" type="text">
      </div>

      <div>
        <span>분류: </span>
        <input name="classification" type="text">
      </div>

      <div>
        <span>주소:</span>
        <input name="address" type="text">
      </div>

      <div>
        <span>가게 전화번호:</span>
        <input name="phone" type="text">
      </div>

      <div style="text-align: center; margin-top: 30px;">
          <button type="submit" onclick="" >등록하기</button>
        </div>


        <div style="text-align: center; margin-top: 90px;">
          <a href="/ci/index.php/Main/owner_page">뒤로가기</a>
        </div>
      
    </form>
  </div>

  </section>
  
</body>
</html>