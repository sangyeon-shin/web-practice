<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>신상닷컴</title>
  <style>
    section{
      text-align: center;
    }
  </style>
</head>
<body>
  <section>
    <a href="/ci/index.php/Main/main"><h1>신상닷컴</h1></a>
    <button onclick = "location.href = '/ci/index.php/Main/add_store'">가게 등록하기</button>
  </section>
  
</body>
</html>