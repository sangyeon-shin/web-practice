<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>신상닷컴</title>
  <style>
    section{
      text-align: center;
      font-size: 35px;
    }
    button{
      font-size: large;
      height: 40px;
    }
  </style>
</head>
<body>

  <section>
    <h1>신상닷컴</h1>
    <h3>맛집 리뷰 서비스</h3>
    <button id="user" onclick = "location.href = '/ci/index.php/Main/store_list'">일반회원으로 시작하기</button>
    <button id="owner" onclick = "location.href = '/ci/index.php/Main/owner_page'">업주회원으로 시작하기</button>
  </section>
  
</body>
</html>