<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>신상닷컴</title>
  <style>
        section{
      text-align: center;
    }
  </style>
</head>
<body>
  <section>
    <a href="main.html"><a href="/ci/index.php/Main/main"><h1>신상닷컴</h1></a></a>
      <table width ="500" border="1" align="center">
        <tr align ="center">
      <td colspan = "4">맛집 리스트</td>
        </tr>
        <tr align = "center" >
          <td>가게 이름</td>
      <td>분류</td>
      <td>주소</td>
      <td>해시태그</td>
        </tr>

        <tr>
      <td><a href="/ci/index.php/Main/store_detail">할매순대국</a></td>
      <td>국밥</td>
      <td>경기</td>
      <td>#가성비</td>
        </tr>

        <tr>
          <td><a href="/ci/index.php/Main/store_detail">맛있는찜닭</a></td>
          <td>닭</td>
          <td>서울</td>
          <td>#신선</td>
        </tr>

        <tr>
          <td><a href="/ci/index.php/Main/store_detail">치즈킹피자</a></td>
          <td>피자</td>
          <td>인천</td>
          <td>#치즈</td>
        </tr>

    </table>

  </section>
  
</body>
</html>