<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>신상닷컴</title>
  <style>
        section{
      text-align: center;
    }
    table{
      margin-bottom: 40px;
    }
    input{
      border: none;
    }
  </style>
</head>
<body>
  <section>
    <a href="main.html"><h1>신상닷컴</h1></a>
    <h1>맛있는찜닭_샘플</h1>
    <table width ="500" align="center">
      <tr>
        <td style="font-weight: bold;">분류:</td>
        <td>찜/탕</td>
      </tr>
      <tr>
        <td style="font-weight: bold;">주소:</td>
        <td>서울 동대문구</td>
      </tr>
      <tr>
        <td style="font-weight: bold;">전화번호:</td>
        <td>02-123-1134</td>
      </tr>
      <tr>
        <td style="font-weight: bold;">메뉴:</td>
        <td>양념찜닭, 간장찜닭, 주먹밥, 막국수, 쫄면</td>
      </tr>
      <tr>
        <td style="font-weight: bold;">해시태그:</td>
        <td>#신선</td>
      </tr>
    </table>

      <table width ="500" border="1" align="center">
        <tr>
          <td>유저아이디</td>
          <td style="width: 75%;">리뷰</td>
        </tr>
        <tr>
          <td>유저1</td>
          <td>신선하고 좋습니다</td>
        </tr>
      </table>

      <form action="#">
        <h4>댓글달기</h4>

        <span style="border:1px solid black;">
          <input type="text" name="id" value="게스트" readonly>
        </span>
        <span style="border:1px solid black;">
          <input type="text" name="review">
        </span>
              <button type="submit">입력</button>

      </form>
      <div style="margin-top: 30px">
        <button onclick="location.href = '/user_list.html'"> 리스트로 돌아가기</button>
      </div>


  </section>
  
</body>
</html>