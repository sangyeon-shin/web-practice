package ex06;

import java.awt.Label;
import java.awt.Panel;

public class MemberPanel extends Panel {
	public MemberPanel() {
		Label label = new Label("회원 화면");
		add(label);
	}
}
