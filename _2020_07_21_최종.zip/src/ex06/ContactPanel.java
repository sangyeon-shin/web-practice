package ex06;

import java.awt.Label;
import java.awt.Panel;

public class ContactPanel extends Panel {
	public ContactPanel() {
		Label label = new Label("연락처 화면");
		add(label);
	}
}
