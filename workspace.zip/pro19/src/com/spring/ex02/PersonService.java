package com.spring.ex02;

public interface PersonService {
	public void sayHello();
}
