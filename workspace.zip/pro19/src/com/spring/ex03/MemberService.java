package com.spring.ex03;

public interface MemberService {
	public void listMembers();
}
