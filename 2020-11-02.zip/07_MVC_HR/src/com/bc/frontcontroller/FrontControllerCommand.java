package com.bc.frontcontroller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bc.model.command.Command;
import com.bc.model.command.DeptCommand;
import com.bc.model.command.DeptListCommand;
import com.bc.model.command.ListCommand;


@WebServlet("/controller")
public class FrontControllerCommand extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(">> FrontControllerCommand.doGet() 실행");
		//요청을 확인하고 처리
		String type = request.getParameter("type");
		Command command = null;
		System.out.println(type);
		if("all".equals(type)) {
			System.out.println(" all 요청 처리");
			command = new ListCommand();
		}else if("dept".equals(type)) {
			System.out.println(" dept 요청 처리");
			command = new DeptCommand();
		}else if("deptList".equals(type)) {
			System.out.println(" dept 요청 처리");
			command = new DeptListCommand();
		}
		
		String path = command.exec(request, response);
		request.getRequestDispatcher(path).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(">> FrontControllerCommand.doPost() 실행");
		request.setCharacterEncoding("UTF-8");
		doGet(request,response);
	}

}
