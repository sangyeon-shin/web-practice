package com.project.board.service;

import java.util.List;

import com.project.board.vo.BoardVO;

public interface BoardService {
	List<BoardVO> getList();
}
