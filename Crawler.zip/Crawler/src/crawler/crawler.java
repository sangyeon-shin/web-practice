package crawler;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class crawler {
	public static void main(String args[]) {
		try {
			String URL = "http://3.35.186.15:8080/Shop/main/main.do";
			
			Connection conn = Jsoup.connect(URL);
			
			Document html = conn.get();
			
			System.out.println("[Attribute Ž��]");
			Elements fileblocks = html.getElementsByClass("container");
			for(Element fileblock : fileblocks) {
				
				Elements files = fileblock.getElementsByTag("div");
				for(Element elm : files) {
					String text = elm.text();
					String href = elm.attr("href");
					
					System.out.println( text+ " > "+href);
				}
			}
			
			System.out.println("[\n[CSS Selector Ž��]");
			Elements files = html.select(".fileblock a");
			for( Element elm : files) {
				String text = elm.text();
				String href = elm.attr("href");
				
				System.out.println( text+ " > "+href);
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
