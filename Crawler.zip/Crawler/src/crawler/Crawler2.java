package crawler;

import java.io.File;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

public class Crawler2 {
	private static ExecutorService executorService = null;
	private static Connection conn = null;
	private static Properties options = null;
	
	public Crawler2() {
		executorService = Executors.newFixedThreadPool(Const.DEFAULT_THREADS);
		
	}
	
	public Crawler2(String URL) {
		executorService = Executors.newFixedThreadPool(Const.DEFAULT_THREADS);
		
		conn = Jsoup.connect(URL);
	}
	
	public Crawler2(String URL, Properties options)throws Exception{
		executorService = Executors.newFixedThreadPool(Const.DEFAULT_THREADS);
		
		conn = Jsoup.connect(URL);
		setOptions(options);
	}
	
	@SuppressWarnings("unchecked")
	public void setOptions(Properties _option)throws Exception{
		options = _option;
		
		final String downloads = options.getProperty("downloads", Const.DEFAULT_DOWNLOADS);
		File file = new File(downloads);
		if(!file.exists() || file.isDirectory()) {
			file.mkdirs();
		}
		
		if(conn==null)return;
		
		if(_option.get("headers") != null) {
			conn.headers((Map<String,String>)_option.get("headers"));
		}
	}
}
